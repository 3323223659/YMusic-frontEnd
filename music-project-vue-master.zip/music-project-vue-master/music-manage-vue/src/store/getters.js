const getters = {
  token: state => state.admin.token,
}
export default getters
